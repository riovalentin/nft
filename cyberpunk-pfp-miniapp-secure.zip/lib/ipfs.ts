import { Web3Storage } from "web3.storage";
export const w3 = new Web3Storage({ token: process.env.WEB3_STORAGE_TOKEN! });
