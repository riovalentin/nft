import { defineConfig } from "@farcaster/minikit";

export default defineConfig({
  appName: "Cyberpunk PFP Mini App",
  icon: "/icon.png",
  homepage: "/",
});
